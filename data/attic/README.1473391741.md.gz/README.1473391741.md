# Creative Kids Wiki

Welcome to the Creative Kids Wiki! This contains documentation and other information shared by students and teachers learning about creative computer programming! Enjoy!
